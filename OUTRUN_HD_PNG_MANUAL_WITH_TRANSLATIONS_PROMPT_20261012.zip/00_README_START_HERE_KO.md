# OutRun 2006 수동 이미지 번역 패키지 (2026-10-12)
HD GUI 소스 17개 중 번역 매핑이 존재하고 PNG 변환 검증이 가능한 자산 12개를 포함합니다.
이 자료는 전체 80개 텍스트 현지화 대상 전체가 아니라 현재 확보한 HD 원본의 일부입니다.

## 작업 순서
(1) ZIP을 풀고 PNG 하나를 ChatGPT 이미지 생성에 첨부합니다.
(2) 01_TRANSLATIONS_BY_PNG.csv에서 해당 파일명의 승인 번역을 확인합니다.
(3) 02_COPY_PASTE_IMAGEGEN_PROMPT_KO.txt를 그대로 붙여넣고 원본 PNG의 번역 이미지를 생성합니다.
(4) 결과를 원본과 대응되는 이름으로 별도 저장합니다.
(5) 혼합방향 미확정 원본은 임의로 게임 DDS에 넣지 말고 스프라이트별 방향을 검증합니다.

## 방향·해상도
- *_READABLE_NORMAL_VERIFIED.png: 해당 원본 DDS의 텍스트 정방향 NORMAL 확인.
- *_READABLE_FLIPY.png: 해당 텍스트 세로 반전 정방향 확인.
- *_FLIPY_CHECK_ORIENTATION.png: 전체 이미지는 뒤집혔지만, 혼합방향 아틀라스여서 스프라이트별 방향은 미확정. 한글화 참고 미리보기만 가능합니다.
- 해상도와 투명 알파 유지. CANVAS 크기만 맞춰서 이미지 전체를 강제로 늘리거나 비문자 부분을 생성하지 않습니다.

## 파일 구성
01_TRANSLATIONS_BY_PNG.csv : 현재 PNG와 직접 대응되는 한국어 번역표 (엑셀 UTF-8 BOM)
02_COPY_PASTE_IMAGEGEN_PROMPT_KO.txt : 공통 복사용 프롬프트
03_PNG_DDS_SHA256_ORIENTATION.csv : 원본 DDS / PNG SHA 및 방향 기록
04_FULL_TRANSLATION_REFERENCE.csv : 현재 전사표에 등록된 전체 DDS용 영문→한글 기록 (이미지가 없는 항목 포함)
05_MISSING_HD_SOURCE_INDEX.csv : 현재 17개 HD 세트에서 원본 파일이 없는 번역 항목
06_ASSET_MANIFEST.json : 전체 PNG 메타/소스 SHA/번역 개별 기록
transcriptions.jsonl : 원전사 기록
CURRENT_IMAGEGEN_POLICY.md / ORIENTATION_POLICY.md / STAGE_NAME_POLICY.md : 제작·방향 정책

원본 HD 파일 SHA는 실제 source DDS를 읽고 계산했습니다. PNG는 각 파일의 크기·PNG 디코딩 검사 후 수록합니다.
게임 패치 배포 또는 실게임에서 정상 동작 검증을 의미하지 않습니다: RUNTIME_VALIDATION=UNTESTED.
