# DX9Ex R84 optimization source review

Pinned HEAD: a509b44ba0c8107a663cdb4f871d2a0204d5fc8e
Branch: vr-d3d9ex-focus
Source files: 15

This archive is a focused extract, NOT a buildable complete project. Key dependencies remain in the GitHub repository at the same SHA.
Check R84 live owner path and avoid R26-only fixes. Host and game frame synchronization, state restoration, draw/HUD correctness, and GPU stalls are review priorities.

## Included source files
- `src/vr/d3d9/stereo_renderer_r33.cpp` — R84 top-level stereo renderer and state/capture path
- `src/vr/d3d9/stereo_renderer_r32.cpp` — R32 DirectGPU interop and rebind
- `src/vr/d3d9/stereo_renderer_r31.cpp` — R31 rendering/state owner
- `src/vr/d3d9/stereo_renderer_r30.cpp` — R30 HUD shadow and draw path
- `src/vr/d3d9/stereo_renderer_r29.cpp` — R29 stereo/transport ownership
- `src/vr/d3d9/stereo_renderer.cpp` — Main D3D9 renderer entry/dispatch
- `src/vr/game/outrun_renderer_r29.cpp` — OutRun game-specific render/visual semantics
- `src/hooks_graphics.cpp` — Original graphics-hook integration
- `src/vr/state/state_block_tracker.hpp` — D3D9 state-block restore and ownership
- `src/vr/d3d9/gpu_water_profiler.hpp` — Async GPU water/transparent perf profiling
- `src/vr/core/r29_owner_api.hpp` — VR owner/transport API boundary
- `src/vr/ipc/coherent_host_identity.hpp` — Restart-safe host PID / LUID snapshot
- `src/vr/ipc/protocol.hpp` — x86-game to x64-host IPC protocol
- `vrhost/src/main_r23.cpp` — x64 OpenXR/D3D11 host mainline
- `vrhost/src/runtime/d3d9ex_direct_passthrough_r32.hpp` — R32 DirectGPU passthrough and frame handling
