OutRun 2006 HD 원본 DDS -> PNG 수동 한글화 파일 / 2026-10-12

이 폴더는 한글화용 HD 원본 DDS 일부를 PNG로 변환한 자료입니다.
READABLE_FLIPY: 원본 영문 표시 방향에서 FLIP-Y가 확인된 대상입니다.
FLIPY_CHECK_ORIENTATION: 세로 반전 미리보기만 적용했습니다. 혼합 방향 atlas는 글자별/스프라이트별 회전·반전 확인이 필요하며, 이를 검증된 정방향으로 취급하지 마세요.
원본 DDS와 1:1 대응하도록 q번호/해시가 PNG 파일명에 포함되어 있습니다.
승인 그래픽 번역 원문: transcriptions.jsonl의 index 별 segments.source / segments.korean.
translation_runtime_draft.json은 게임 내부 문자열용 초안이므로 DDS 이미지 번역과 구분하세요.
중요 오타 방지: "15 continuous course" = "15코스 연속".
유지할 것: 음악 제목, 자동차 모델/제조사/브랜드/로고, 차량/아이콘, 배경, 번역 대상 외 글자.
생성 시 원본 서체·색상·기울기 방향·테두리·그림자·빛 효과에 최대한 맞추고 한글 자소를 정확히 표기하세요.
글자는 원본 UI 칸 내부, 충돌·잘림·픽셀 침범 금지. 번역이 짧거나 약간 작아도 문제 없습니다.
원본 투명도/캔버스를 유지하십시오. 모델 출력으로 원본 픽셀이 100% 보존된다고 가정하지 마세요.
결과 PNG는 원본명 뒤에 _KO를 붙여 전달하면 원본과 대응하여 후처리합니다.
원래 DDS RAW 방향 복원·CLEAN 합성·원래 DDS 포맷/mips 보존·독립 C1/C3 QA는 후처리 단계입니다.
실제 게임은 검증하지 않았으며 RUNTIME_VALIDATION=UNTESTED 입니다.
이 ZIP은 확보된 원본 DDS의 일부만 포함합니다. 전체 프로젝트 번역 대상 전량이 아닙니다.
