Batch51 37759842 connected-component icon reconstruction.
