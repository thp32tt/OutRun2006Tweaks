OutRun 2006 Korean Graphics — FULL DRAFT TEST PACKAGE

STATUS: TEST ONLY / NOT FINAL

Coverage
- DDS files included: 79 / 79
- Korean text segments rendered: 674 / 674
- Final in-game validated assets: 0 / 79

Placement methods
{
  "exact": 8,
  "ocr": 225,
  "alpha-heuristic": 330,
  "manual": 28,
  "alpha-order": 51,
  "alpha-special159": 15,
  "alpha-special201": 14,
  "manual-special201": 3
}

DDS preservation
- RGBA32: original 128-byte header and mip count preserved.
- DXT5: re-encoded as DXT5 using the original mip count.
- Full per-file hashes and conversion mode: manifest.json

Install
1. Back up any existing texture replacement files that use the same paths.
2. Copy the included textures folder into the OutRun 2006 game directory.
3. Set UITextureReplacement = true in OutRun2006Tweaks.ini.
4. Run the game and capture screenshots where Korean is clipped, misplaced, mirrored, missing, or has the wrong color/style.

Rollback
Delete the replacement DDS files listed in manifest.json, or restore your previous texture replacement folder. The original packed game assets are not modified.

Important
This package is intentionally a complete 79-asset draft for broad in-game testing. Large atlases use heuristic placement where exact sprite coordinates have not yet been runtime-verified. Do not treat it as a release build until screenshots are reviewed.
