# OutRun 2006 — B/C1 transparent English-letter reference pack
Version 2026-10-12. SHA-verified source-only imagery. No OpenAI API calls.
This bundle contains ONLY original English lettering/effects cropped PNGs.
No Korean art is generated and no C2/C3/game approval is conferred.

HOW TO USE WITH CHATGPT PROJECT
1. Upload this ZIP to the ChatGPT Project for storage/indexing.
2. For an IMAGE EDIT request, attach the precise SINGLE PNG from INPUTS/ to
   the actual conversation/message with the image generator. Merely uploading
   ZIP to Project, placing a GitHub URL in prompt, or previewing with another
   tool does NOT prove the native ImageGen model received the source pixels.
3. Ask for the Korean target shown in manifest.json, preserve the original
   letter style, and request transparent LETTERING ONLY.
4. Check the generated image's exact Hangul, transparent alpha, no UI/scenery,
   then allow original source/CLEAN/C2 gating and DDS conversion separately.
5. Never assert media_attached=true or fabricate a tool receipt. If the
   generator cannot actually see the attached source => SOURCE_REFERENCE_NOT_BOUND.

FOLDER RULE: INPUTS/ contains SINGLE-IMAGE references for ImageGen.
Do NOT attach human review contact sheets or entire asset atlases.
C1 q098 two variants: the CANONICAL ref for game pixels, and PSD_STYLE ref
for family appearance; avoid mixing them as though pixel-equal.
q230 style refs are color-unmatted approximate and target translations
must be independently determined (null in manifest). Existing in-flight
ownership of q098/q230 must be respected.
B q092 PSD source is not yet certified pixel-exact game source.
No PLATE_PASS, final DDS, official export or runtime PASS is implied.

GitHub source: thp32tt/OutRun2006Tweaks
Branch at preparation: korean-localization-recovery-20260928
Each entry is sha256-verified against its source. See manifest.json.

Use without paid API: upload the individual transparent PNG directly in
ChatGPT when starting the image edit. Persistent Project storage can help
people find files but is not, by itself, a verified model image attachment.
