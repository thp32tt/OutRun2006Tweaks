OutRun 2006 C1 q030 source-only upload packet (2026-10-13).
These are English-only transparent PNG references, NOT Korean translated outputs.
Upload ONE of the original PNGs in the ChatGPT message with the corresponding prompt.
External PSD extraction is not a verified canonical DDS/approved CLEAN source.
Historical q030 B production ownership/C392 REWORK stays open; no silent transfer.
No automatic producer self-approval, C2/C3/game approval, or official DDS.
This archive was compiled from SHA-matched existing GitHub PNG bytes.
